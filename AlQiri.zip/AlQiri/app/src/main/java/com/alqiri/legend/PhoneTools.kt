package com.alqiri.legend

import android.Manifest
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * The phone actions (security scan, files, calls, SMS, caller ID, location).
 * Context-based so it works from the screen (MainActivity) AND from the hands-free service (WakeService).
 * [speaker] reads a short note aloud; [confirmer] asks the human to approve outgoing actions (dialog or voice).
 */
class PhoneTools(
    private val ctx: Context,
    private val speaker: (String) -> Unit,
    private val confirmer: suspend (String) -> Boolean
) : AlQiriHost {

    override suspend fun confirm(text: String): Boolean = confirmer(text)

    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    // =====================================================================
    //  Storage helpers
    // =====================================================================
    private val badChars = Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]")

    private fun safeName(s: String, fallback: String): String {
        val c = s.replace(badChars, "_").replace("..", "_").trim().trim('.').take(60)
        return c.ifBlank { fallback }
    }

    /** Preferred: /sdcard/Al-Qiri. Fallback (no "All files access"): the app's own external folder. */
    private fun candidateRoots(): List<File> = listOf(
        File(Environment.getExternalStorageDirectory(), "Al-Qiri"),
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Al-Qiri")
    )

    private fun existingRoots(): List<File> = candidateRoots().filter { it.exists() && it.isDirectory }

    private fun filesIn(folder: String): List<File> =
        existingRoots().flatMap { File(it, safeName(folder, "عام")).listFiles()?.filter { f -> f.isFile }.orEmpty() }
            .sortedByDescending { it.lastModified() }

    private fun fmtDate(ms: Long) = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(ms))

    // =====================================================================
    //  1) Security scan
    // =====================================================================
    private fun appLabel(pkg: String): String = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    override fun scanPhoneSecurityUltimate(): String {
        var score = 100
        val problems = mutableListOf<String>()
        val good = mutableListOf<String>()

        // Root
        val suPaths = listOf("/system/xbin/su", "/system/bin/su", "/sbin/su", "/su/bin/su", "/system/app/Superuser.apk")
        val rooted = suPaths.any { try { File(it).exists() } catch (e: Exception) { false } }
        if (rooted) {
            score -= 50
            problems += "🚨 جوالك مرووت (Root)! هذا يفتح الباب للتجسس والفيروسات.\n   ✅ الحل: لا تحط عليه بيانات بنك، وارجع النظام الرسمي (Stock ROM) او لا تثبت اي تطبيق مو موثوق."
        } else good += "جوالك مو مرووت"

        // ADB (Settings.Global.ADB_ENABLED is the modern home of Settings.Secure.ADB_ENABLED)
        val adbOn = try { Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1 } catch (e: Exception) { false }
        if (adbOn) {
            score -= 20
            problems += "⚠️ تصحيح USB (ADB) شغّال — اي كمبيوتر توصّل به تقدر يدخل جوالك.\n   ✅ الحل: الاعدادات ← خيارات المطور ← اطفي «تصحيح USB»."
        } else good += "تصحيح USB مطفي"

        // Accessibility services
        val acc = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val services = acc.split(":").filter { it.isNotBlank() }
        if (services.isNotEmpty()) {
            score -= minOf(30, services.size * 15)
            val names = services.map { appLabel(it.substringBefore('/')) }.distinct().joinToString("، ")
            problems += "⚠️ فيه ${services.size} خدمة امكانية وصول شغّالة: $names\n   هذي الصلاحية تقدر تقرا الشاشة وتضغط بدالك. لو تعرفها (قارئ شاشة، مدير كلمات سر…) عادي، لو ما تعرفها فهي مشبوهة.\n   ✅ الحل: الاعدادات ← امكانية الوصول ← الخدمات المثبتة ← اطفي اللي ما تعرفه."
        } else good += "ما فيه خدمات امكانية وصول مشبوهة"

        // Screen lock
        val secure = try { ctx.getSystemService(KeyguardManager::class.java)?.isDeviceSecure ?: true } catch (e: Exception) { true }
        if (!secure) {
            score -= 15
            problems += "⚠️ ما عندك قفل شاشة — اي احد يمسك جوالك يشوف كل شي.\n   ✅ الحل: الاعدادات ← شاشة القفل ← بصمة او رمز."
        } else good += "قفل الشاشة مفعّل"

        score = score.coerceIn(0, 100)
        val verdict = when {
            score >= 80 -> "🟢 جوالك بأمان يا زعيم 👌"
            score >= 50 -> "🟡 فيه ملاحظات لازم تنتبه لها"
            else -> "🔴 الوضع خطير يا زعيم! لازم تعالج ذا الحين"
        }
        val sb = StringBuilder("🛡️ فحص الجوال — النتيجة: $score/100\n$verdict\n")
        if (problems.isNotEmpty()) sb.append("\n❗ المشاكل:\n").append(problems.joinToString("\n\n")).append("\n")
        if (good.isNotEmpty()) sb.append("\n✔️ سليم: ").append(good.joinToString("، "))
        return sb.toString().trim()
    }

    // =====================================================================
    //  2) Save file
    // =====================================================================
    override fun saveToAlQiriFile(folder: String, fileName: String, content: String): String {
        val f = safeName(folder, "عام")
        val n = safeName(fileName, "ملف_" + stamp())
        for (root in candidateRoots()) {
            try {
                val dir = File(root, f)
                if (!dir.exists() && !dir.mkdirs()) continue
                val file = File(dir, "$n.txt")
                if (!file.canonicalPath.startsWith(root.canonicalPath)) continue
                file.writeText(content, Charsets.UTF_8)
                return "تم الحفظ ✅ ${file.absolutePath}"
            } catch (e: Exception) {
                // try the next location
            }
        }
        return "ما قدرت احفظ الملف يا زعيم ❌ تأكد من صلاحية الملفات."
    }

    // =====================================================================
    //  3) List files
    // =====================================================================
    override fun getAlQiriFiles(folder: String): String {
        val roots = existingRoots()
        if (roots.isEmpty()) return "ما فيه ملفات محفوظة للحين يا زعيم 📂"
        val f = folder.trim()
        if (f.isEmpty()) {
            val names = roots.flatMap { it.listFiles()?.filter { d -> d.isDirectory }.orEmpty() }.map { it.name }.distinct()
            val sb = StringBuilder()
            var total = 0
            for (name in names) {
                val c = filesIn(name).size
                if (c > 0) sb.append("📁 ${name.replace('_', ' ')}: $c ملف\n")
                total += c
            }
            if (total == 0) return "ما فيه ملفات محفوظة للحين يا زعيم 📂"
            return "📂 ملفاتك في Al-Qiri ($total ملف):\n${sb.toString().trim()}\n📍 ${roots.first().absolutePath}"
        }
        val files = filesIn(f)
        if (files.isEmpty()) return "المجلد «${f.replace('_', ' ')}» فاضي للحين."
        val lines = files.take(30).joinToString("\n") { "• ${it.name}  (${(it.length() + 1023) / 1024} KB • ${fmtDate(it.lastModified())})" }
        return "📂 ${f.replace('_', ' ')} — ${files.size} ملف:\n$lines\n📍 ${files.first().parent}"
    }

    // =====================================================================
    //  5) Calls, SMS, contacts
    // =====================================================================
    override fun findContactNumber(name: String): String? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val q = normArabic(name.trim())
        if (q.isEmpty()) return null
        var exact: String? = null
        var partial: String? = null
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, "${Phone.DISPLAY_NAME} ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = normArabic(c.getString(0) ?: continue)
                    val num = c.getString(1) ?: continue
                    if (n == q) { exact = num; break }
                    if (partial == null && n.contains(q)) partial = num
                }
            }
        } catch (e: Exception) { /* no contacts access */ }
        return exact ?: partial
    }

    private fun resolveNumber(who: String): String? {
        val d = digitsOf(who)
        if (d.length >= 5 && who.count { it.isLetter() } == 0) {
            return (if (who.trim().startsWith("+")) "+" else "") + d
        }
        return findContactNumber(who)?.filter { it.isDigit() || it == '+' }
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        (if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else null) ?: SmsManager.getDefault()

    /** Returns null on success, or an Arabic error message. */
    private fun smsSend(number: String, message: String): String? {
        if (!has(Manifest.permission.SEND_SMS)) return "لازم تعطيني صلاحية ارسال الرسائل 📩 من القائمة ← منح الصلاحيات."
        if (message.isBlank()) return "الرسالة فاضية يا زعيم."
        return try {
            val sms = smsManager()
            val parts = sms.divideMessage(message)
            if (parts.size > 1) sms.sendMultipartTextMessage(number, null, parts, null, null)
            else sms.sendTextMessage(number, null, message, null, null)
            null
        } catch (e: Exception) {
            "ما قدرت ارسل الرسالة ❌ (${e.message})"
        }
    }

    override fun dialAndSpeak(phone: String, message: String): String {
        if (!has(Manifest.permission.CALL_PHONE)) return "لازم تعطيني صلاحية الاتصال 📞 من القائمة ← منح الصلاحيات."
        val number = resolveNumber(phone) ?: return "ما لقيت رقم او جهة اتصال باسم «$phone» يا زعيم."
        return try {
            // TelecomManager.placeCall also works when the app is in the background (hands-free mode).
            val telecom = ctx.getSystemService(TelecomManager::class.java)
            if (telecom != null) {
                telecom.placeCall(Uri.fromParts("tel", number, null), Bundle())
            } else {
                val i = Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                Handler(Looper.getMainLooper()).post { ctx.startActivity(i) }
            }
            saveToAlQiriFile(
                "المكالمات", "اتصال_${stamp()}",
                "الى: $phone\nالرقم: $number\nالوقت: ${fmtDate(System.currentTimeMillis())}\nالملاحظة: ${message.ifBlank { "-" }}"
            )
            if (message.isNotBlank()) speaker("تذكير: $message")
            "جاري الاتصال بـ $phone ($number) 📞" +
                (if (message.isNotBlank()) "\n📝 تذكير لك: «$message» (اندرويد ما يسمح لي انطق داخل المكالمة، قلتها لك بصوتي)" else "")
        } catch (e: Exception) {
            "ما قدرت اتصل ❌ (${e.message})"
        }
    }

    override fun sendSmsToContact(phone: String, message: String): String {
        val number = resolveNumber(phone) ?: return "ما لقيت رقم او جهة اتصال باسم «$phone» يا زعيم."
        smsSend(number, message)?.let { return it }
        saveToAlQiriFile(
            "الرسائل", "رسالة_${stamp()}",
            "الى: $phone\nالرقم: $number\nالوقت: ${fmtDate(System.currentTimeMillis())}\nالنص: $message"
        )
        return "تم ارسال الرسالة ✅ الى $phone ($number)"
    }

    // =====================================================================
    //  6) Caller ID
    // =====================================================================
    private fun carrierOf(local: String, raw: String): String {
        if (local.length == 9 && local.startsWith("7")) {
            return when (local.take(2)) {
                "77", "73" -> "يمن موبايل"
                "71" -> "سبأفون"
                "70", "78" -> "YOU (واي)"
                else -> "مشغل يمني غير معروف"
            }
        }
        val r = raw.trim()
        return if ((r.startsWith("+") && !r.startsWith("+967")) || (r.startsWith("00") && !r.startsWith("00967")))
            "رقم دولي (مو يمني)" else "خط ارضي او رقم غير مصنّف"
    }

    private fun contactNameFor(candidates: List<String>): String? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        for (c in candidates) {
            try {
                val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(c))
                val name = ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                    ?.use { cur -> if (cur.moveToFirst()) cur.getString(0) else null }
                if (name != null) return name
            } catch (e: Exception) { /* keep trying */ }
        }
        return null
    }

    private fun callHistory(local: String): String {
        if (!has(Manifest.permission.READ_CALL_LOG)) return ""
        return try {
            var count = 0
            var last = 0L
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.DATE), "${CallLog.Calls.NUMBER} LIKE ?",
                arrayOf("%$local"), "${CallLog.Calls.DATE} DESC"
            )?.use { c ->
                count = c.count
                if (c.moveToFirst()) { last = c.getLong(0) }
            }
            if (count == 0) "📞 سجل المكالمات: ما اتصل بك ولا اتصلت به" else "📞 سجل المكالمات: $count مكالمة، اخرها ${fmtDate(last)}"
        } catch (e: Exception) { "" }
    }

    override fun lookupCallerID(number: String): String {
        val digits = digitsOf(number)
        if (digits.length < 5) return "الرقم قصير يا زعيم، اكتبه كامل مثل 771234567"
        var local = digits
        when {
            local.startsWith("00967") -> local = local.removePrefix("00967")
            local.startsWith("967") -> local = local.removePrefix("967")
            local.startsWith("0") -> local = local.removePrefix("0")
        }
        val carrier = carrierOf(local, number)
        val name = contactNameFor(listOf(number.trim(), "+967$local", local, "0$local").distinct())
        val history = callHistory(local)

        val sb = StringBuilder("🔎 نتيجة البحث عن الرقم ${number.trim()}\n")
        sb.append("📡 المشغل: $carrier\n")
        sb.append(if (name != null) "👤 الاسم في جهاتك: $name\n" else "👤 الاسم: غير مسجل عندك\n")
        if (history.isNotBlank()) sb.append(history).append("\n")
        if (name == null) {
            val saved = saveToAlQiriFile(
                "الارقام_المجهولة", "رقم_$local",
                "الرقم: $number\nالمشغل: $carrier\nتاريخ البحث: ${fmtDate(System.currentTimeMillis())}\n$history"
            )
            sb.append("💾 $saved\n")
            sb.append("🚫 تحب احظره؟ الحظر من تطبيق الهاتف: السجل ← اضغط على الرقم ← حظر / ابلاغ عن رقم مزعج.")
        }
        return sb.toString().trim()
    }

    // =====================================================================
    //  7) Find my phone
    // =====================================================================
    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    private fun freshLocation(lm: LocationManager): Location? {
        val provider = when {
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> return null
        }
        val latch = CountDownLatch(1)
        var result: Location? = null
        val cancel = CancellationSignal()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(provider, cancel, ContextCompat.getMainExecutor(ctx)) { loc ->
                    result = loc
                    latch.countDown()
                }
            } else {
                lm.requestSingleUpdate(provider, object : LocationListener {
                    override fun onLocationChanged(location: Location) { result = location; latch.countDown() }
                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }, Looper.getMainLooper())
            }
            latch.await(12, TimeUnit.SECONDS)
        } catch (e: Exception) {
            // ignore, fall through with whatever we have
        } finally {
            cancel.cancel()
        }
        return result
    }

    @SuppressLint("MissingPermission")
    private fun bestLocation(): Location? {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION) && !has(Manifest.permission.ACCESS_COARSE_LOCATION)) return null
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
        var best: Location? = null
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } ?: continue
            val b = best
            if (b == null || l.time > b.time) best = l
        }
        val b = best
        if (b == null || System.currentTimeMillis() - b.time > 180_000L) {
            freshLocation(lm)?.let { best = it }
        }
        return best
    }

    private fun mapsLink(l: Location): String =
        "https://www.google.com/maps?q=" + String.format(Locale.US, "%.6f,%.6f", l.latitude, l.longitude)

    override fun findMyPhone(): String {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION) && !has(Manifest.permission.ACCESS_COARSE_LOCATION))
            return "لازم تعطيني صلاحية الموقع 📍 من القائمة ← منح الصلاحيات."
        val loc = bestLocation() ?: return "ما قدرت احدد موقع الجوال ❌ تأكد ان الـ GPS شغّال وجرّب برا المبنى."
        val link = mapsLink(loc)
        val acc = if (loc.hasAccuracy()) " (الدقة تقريباً ${loc.accuracy.toInt()} متر)" else ""
        val saved = saveToAlQiriFile(
            "المواقع", "موقع_${stamp()}",
            "الرابط: $link\nخط العرض: ${loc.latitude}\nخط الطول: ${loc.longitude}\nالوقت: ${fmtDate(System.currentTimeMillis())}"
        )
        return "لقيت جوالك يا زعيم 📍$acc\n$link\n$saved"
    }

    // =====================================================================
    //  8) Share / request location by SMS
    // =====================================================================
    override fun shareMyLocationWith(name: String): String {
        val number = resolveNumber(name) ?: return "ما لقيت رقم او جهة اتصال باسم «$name» يا زعيم."
        val loc = bestLocation() ?: return "ما قدرت احدد موقعك ❌ تأكد من صلاحية الموقع وان الـ GPS شغّال."
        val link = mapsLink(loc)
        smsSend(number, "📍 موقعي الحالي: $link")?.let { return it }
        saveToAlQiriFile(
            "المواقع", "مشاركة_${stamp()}",
            "شاركت موقعي مع: $name ($number)\n$link\nالوقت: ${fmtDate(System.currentTimeMillis())}"
        )
        return "شاركت موقعك مع $name ✅\n$link"
    }

    override fun requestLocationFrom(name: String): String {
        val number = resolveNumber(name) ?: return "ما لقيت رقم او جهة اتصال باسم «$name» يا زعيم."
        smsSend(number, "السلام عليكم، ممكن ترسل لي موقعك الحالي؟ 🙏")?.let { return it }
        saveToAlQiriFile(
            "المواقع", "طلب_موقع_${stamp()}",
            "طلبت موقع: $name ($number)\nالوقت: ${fmtDate(System.currentTimeMillis())}"
        )
        return "ارسلت لـ $name طلب الموقع ✅ اول ما يرد عليك برابط الموقع افتحه."
    }

}
