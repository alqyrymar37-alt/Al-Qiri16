package com.alqiri.legend

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

/**
 * App-blocking parental control, enforced from QiriAccessibilityService (independent of the AI/network).
 * The PIN is stored as a SHA-256 hash inside encrypted prefs, never in plain text.
 */
object ParentalControl {
    private const val FILE = "alqiri_parental"
    @Volatile private var prefs: android.content.SharedPreferences? = null
    private var lastBlockToastAt = 0L

    private fun p(ctx: Context): android.content.SharedPreferences = prefs ?: synchronized(this) {
        prefs ?: run {
            val app = ctx.applicationContext
            val key = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                app, FILE, key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }.also { prefs = it }
    }

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString("") { "%02x".format(it) }

    fun isEnabled(ctx: Context): Boolean = p(ctx).getBoolean("enabled", false)
    fun hasPin(ctx: Context): Boolean = p(ctx).getString("pin_hash", null) != null
    fun checkPin(ctx: Context, pin: String): Boolean = p(ctx).getString("pin_hash", null) == hash(pin)

    fun setPin(ctx: Context, pin: String) {
        p(ctx).edit().putString("pin_hash", hash(pin)).apply()
    }

    fun setEnabled(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("enabled", on).apply()
    }

    fun blockedApps(ctx: Context): Set<String> = p(ctx).getStringSet("blocked", emptySet()) ?: emptySet()

    fun setBlockedApps(ctx: Context, pkgs: Set<String>) {
        p(ctx).edit().putStringSet("blocked", pkgs).apply()
    }

    /** Called by the accessibility service every time the foreground app changes. */
    fun onAppOpened(ctx: Context, pkg: String?) {
        if (pkg.isNullOrBlank() || !isEnabled(ctx)) return
        if (pkg == ctx.packageName) return // never block Al-Qiri itself (needed to enter the PIN)
        if (pkg !in blockedApps(ctx)) return
        val svc = QiriAccessibilityService.instance ?: return
        svc.pressKey("الرئيسية")
        val now = SystemClock.elapsedRealtime()
        if (now - lastBlockToastAt > 3000) {
            lastBlockToastAt = now
            try {
                android.widget.Toast.makeText(ctx, "🔒 هذا التطبيق مقفول من الرقابة الابوية", android.widget.Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {}
        }
    }
}
