package com.alqiri.legend

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

/** Opening, listing and scanning OTHER apps by their Arabic/English name (used by both the AI and the phone-side quick router). */
object AppControl {

    private fun apps(ctx: Context) =
        ctx.packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)

    private fun norm(s: String) = normArabic(s).replace(Regex("\\s+"), "")

    fun findApp(ctx: Context, name: String): Pair<String, String>? { // (label, packageName)
        val q = norm(name)
        if (q.isBlank()) return null
        val pm = ctx.packageManager
        val list = apps(ctx)
        val exact = list.firstOrNull { norm(it.loadLabel(pm).toString()) == q }
        val partial = exact ?: list.firstOrNull { norm(it.loadLabel(pm).toString()).contains(q) || q.contains(norm(it.loadLabel(pm).toString())) }
        return partial?.let { it.loadLabel(pm).toString() to it.activityInfo.packageName }
    }

    fun openApp(ctx: Context, name: String): String {
        val hit = findApp(ctx, name) ?: return "ما لقيت تطبيق اسمه «$name» على جوالك يا زعيم."
        val (label, pkg) = hit
        val launch = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: return "لقيت $label بس ما قدرت افتحه."
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        return "فتحت لك $label ✅"
    }

    fun listApps(ctx: Context): String {
        val pm = ctx.packageManager
        val names = apps(ctx).map { it.loadLabel(pm).toString() }.distinct().sorted()
        if (names.isEmpty()) return "ما لقيت تطبيقات."
        return "📱 تطبيقاتك (${names.size}):\n" + names.joinToString("، ")
    }

    /** A quick, honest permission/risk summary for one app — not a virus scanner. */
    fun scanApp(ctx: Context, name: String): String {
        val hit = findApp(ctx, name) ?: return "ما لقيت تطبيق اسمه «$name» يا زعيم."
        val (label, pkg) = hit
        val pm = ctx.packageManager
        return try {
            val info = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
            val appInfo = pm.getApplicationInfo(pkg, 0)
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val granted = info.requestedPermissions?.filterIndexed { i, _ ->
                (info.requestedPermissionsFlags?.getOrNull(i) ?: 0) and android.content.pm.PackageInfo.REQUESTED_PERMISSION_GRANTED != 0
            }.orEmpty()
            val sensitive = mapOf(
                "CAMERA" to "الكاميرا", "RECORD_AUDIO" to "المايك", "READ_CONTACTS" to "جهات الاتصال",
                "ACCESS_FINE_LOCATION" to "الموقع الدقيق", "READ_SMS" to "الرسائل", "READ_CALL_LOG" to "سجل المكالمات",
                "SEND_SMS" to "ارسال رسائل", "SYSTEM_ALERT_WINDOW" to "الظهور فوق التطبيقات",
                "BIND_ACCESSIBILITY_SERVICE" to "امكانية الوصول (تقدر تقرا شاشتك)"
            )
            val found = granted.mapNotNull { perm -> sensitive.entries.firstOrNull { perm.endsWith(it.key) }?.value }.distinct()
            val sb = StringBuilder("🔍 فحص $label\n")
            sb.append(if (isSystem) "نوعه: تطبيق نظام\n" else "نوعه: تطبيق مثبّت من المستخدم\n")
            if (found.isEmpty()) sb.append("صلاحياته عادية، ما فيه شي يلفت النظر ✅")
            else sb.append("⚠️ صلاحياته الحساسة: ${found.joinToString("، ")}\nلو ما تثق بالتطبيق، سكّرها من الاعدادات ← التطبيقات ← $label ← الاذونات.")
            sb.toString()
        } catch (e: Exception) {
            "ما قدرت افحص $label (${e.message})"
        }
    }
}
